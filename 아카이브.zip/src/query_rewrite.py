from __future__ import annotations

import json
import re
from typing import Any

from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.runnables import Runnable, RunnableLambda
from langchain_openai import ChatOpenAI

from src.config import REWRITE_MODEL, REWRITE_TEMPERATURE


REWRITE_SYSTEM = """You are a query rewriting assistant.

Given the conversation history and the latest user message, rewrite the latest user message into a concise standalone search query.

You must return valid JSON only.

Schema:
{{
  "class": "standalone" | "non-standalone",
  "reworded version": "<standalone search query>"
}}

Rules:
- Output JSON only.
- Do not use markdown code fences.
- Do not provide explanations.
- Do not answer the user's question.
- Do not expand the query into background knowledge.
- Keep the rewritten query short and retrieval-friendly.
- If the latest user message is already standalone, return it unchanged and set "class" to "standalone".
- "reworded version" must be a short search query or question, not a paragraph.
"""


def _strip_code_fences(text: str) -> str:
    text = text.strip()
    text = re.sub(r"^\s*```(?:json)?\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\s*```\s*$", "", text)
    return text.strip()


def _extract_json_object(text: str) -> str | None:
    start = text.find("{")
    if start == -1:
        return None

    depth = 0
    for i in range(start, len(text)):
        ch = text[i]
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return text[start:i + 1]
    return None


def _last_question_like_span(text: str) -> str:
    cleaned = " ".join(text.strip().split())
    if not cleaned:
        return ""

    parts = re.split(r"(?<=[?.!])\s+", cleaned)
    question_parts = [p.strip() for p in parts if "?" in p]
    if question_parts:
        return question_parts[-1]

    short_parts = [p.strip() for p in parts if 0 < len(p.strip()) <= 160]
    if short_parts:
        return short_parts[-1]

    return cleaned[:160].strip()


def _sanitize_query(candidate: str, original_input: str) -> str:
    candidate = " ".join((candidate or "").split()).strip()
    original_input = " ".join((original_input or "").split()).strip()

    if not candidate:
        return original_input

    if len(candidate) > 220:
        shortened = _last_question_like_span(candidate)
        return shortened or original_input

    return candidate


def parse_rewrite_output(payload: dict[str, Any]) -> dict[str, str]:
    raw = str(payload.get("raw", "") or "").strip()
    last_input = str(payload.get("last_input", "") or "").strip()

    cleaned = _strip_code_fences(raw)
    json_candidate = _extract_json_object(cleaned) or cleaned

    rewrite_class = "standalone"
    rewritten_query = last_input

    try:
        parsed = json.loads(json_candidate)

        if isinstance(parsed, dict):
            rewrite_class = str(parsed.get("class", "standalone")).strip() or "standalone"
            reworded = str(parsed.get("reworded version", "")).strip()
            rewritten_query = _sanitize_query(reworded, last_input)
        else:
            rewritten_query = _sanitize_query(cleaned, last_input)

    except Exception as e:
        rewritten_query = _sanitize_query(cleaned, last_input)
        print(f"[WARN] Failed to parse rewrite JSON ({e}); using safe fallback.")

    print(f"[Rewrite Result] class={rewrite_class}, query={rewritten_query}")

    return {
        "rewritten_query": rewritten_query,
        "rewrite_class": rewrite_class,
        "rewrite_raw": raw,
    }


def build_rewrite_chain() -> Runnable:
    llm = ChatOpenAI(model=REWRITE_MODEL, temperature=REWRITE_TEMPERATURE)

    prompt = ChatPromptTemplate.from_messages(
        [
            ("system", REWRITE_SYSTEM),
            MessagesPlaceholder("chat_history"),
            ("human", "{input}"),
        ]
    )

    return (
        {
            "raw": prompt | llm | StrOutputParser(),
            "last_input": lambda x: x["input"],
        }
        | RunnableLambda(parse_rewrite_output)
    )